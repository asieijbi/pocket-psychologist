import { useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, MapPin, MessageCircle, Phone, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { UI_COPY, useLanguage } from "@/lib/i18n";
import {
  APPLICATION_TOPICS,
  applicationSchema,
  findPsychologistByRegion,
  type RegionalPsychologist,
} from "@/lib/routing";
import {
  submitPsychologistApplication,
  type ApplicationReceipt,
} from "@/lib/psychologists.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ApplicationSectionProps {
  psychologists: RegionalPsychologist[];
}

export function ApplicationSection({ psychologists }: ApplicationSectionProps) {
  const { lang, t } = useLanguage();
  const submitFn = useServerFn(submitPsychologistApplication);

  const defaultRegion =
    findPsychologistByRegion(psychologists, "akmola")?.region_code ?? "";
  const [regionCode, setRegionCode] = useState<string>(defaultRegion);
  const [topic, setTopic] = useState<string>("stress");
  const [isAnonymous, setIsAnonymous] = useState<boolean>(true);
  const [applicantName, setApplicantName] = useState<string>("");
  const [contactInfo, setContactInfo] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  const [fieldError, setFieldError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [receipt, setReceipt] = useState<ApplicationReceipt | null>(null);

  const selectedPsychologist = regionCode
    ? findPsychologistByRegion(psychologists, regionCode)
    : undefined;

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setFieldError(null);

    const parsed = applicationSchema.safeParse({
      regionCode,
      topic,
      message,
      isAnonymous,
      applicantName: isAnonymous ? undefined : applicantName,
      contactInfo: contactInfo || undefined,
      language: lang,
    });

    if (!parsed.success) {
      const firstIssue = parsed.error.issues[0];
      setFieldError(firstIssue?.message ?? "Проверьте заполнение полей формы");
      return;
    }

    setIsSubmitting(true);
    const whatsappWindow = window.open("", "_blank");
    try {
      const result = await submitFn({ data: parsed.data });
      setReceipt(result);
      toast.success(t(UI_COPY.successTitle));
      if (whatsappWindow && !whatsappWindow.closed) {
        whatsappWindow.opener = null;
        whatsappWindow.location.href = result.whatsappUrl;
      }
    } catch (err) {
      if (whatsappWindow && !whatsappWindow.closed) {
        whatsappWindow.close();
      }
      const msg =
        err instanceof Error ? err.message : "Не удалось отправить заявку. Попробуйте снова.";
      setFieldError(msg);
      toast.error(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setReceipt(null);
    setMessage("");
    setFieldError(null);
  };

  return (
    <section id="apply" className="border-t border-border bg-surface-subtle py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-start">
          <div className="min-w-0 lg:col-span-5">
            <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
              {t(UI_COPY.applyTitle)}
            </h2>
            <p className="mt-3 text-base leading-relaxed text-muted-foreground">
              {t(UI_COPY.applySubtitle)}
            </p>

            <div className="mt-6 flex items-center gap-2.5 text-sm font-medium text-primary">
              <ShieldCheck className="h-5 w-5 shrink-0 text-azure" />
              <span>{t(UI_COPY.confidentialNote)}</span>
            </div>

            {selectedPsychologist ? (
              <div
                data-testid="assigned-psychologist-card"
                className="mt-6 overflow-hidden rounded-xl border border-gold/50 bg-navy-deep text-hero-foreground shadow-md"
              >
                <div className="gold-rule h-1 w-full" />
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gold">
                    <MapPin className="h-3.5 w-3.5" />
                    <span>
                      {lang === "kk"
                        ? selectedPsychologist.region_name_kk
                        : selectedPsychologist.region_name_ru}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-hero-foreground/70">
                    {t(UI_COPY.assignedLabel)}
                  </p>

                  <div className="mt-4 flex items-start gap-3.5">
                    <img
                      src={emblemUrl}
                      alt=""
                      className="h-12 w-12 shrink-0 object-contain"
                    />
                    <div className="min-w-0">
                      <p className="font-display text-lg font-bold leading-snug text-hero-foreground">
                        {selectedPsychologist.psychologist_name}
                      </p>
                      <p className="mt-1 text-xs text-hero-foreground/85">
                        {lang === "kk"
                          ? selectedPsychologist.rank_kk
                          : selectedPsychologist.rank_ru}
                      </p>
                      <p className="mt-0.5 text-xs text-gold">
                        {lang === "kk"
                          ? selectedPsychologist.department_kk
                          : selectedPsychologist.department_ru}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 border-t border-hero-foreground/15 pt-3 text-xs text-hero-foreground/80">
                    <p className="font-medium text-hero-foreground">
                      WhatsApp / Тел.: {selectedPsychologist.phone_display}
                    </p>
                    {selectedPsychologist.is_demo ? (
                      <p className="mt-1 text-[11px] text-hero-foreground/65">
                        {t(UI_COPY.demoContactNote)}
                      </p>
                    ) : null}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div className="min-w-0 rounded-2xl border border-border bg-card p-5 shadow-sm sm:p-8 lg:col-span-7">
            {receipt ? (
              <div data-testid="application-receipt" className="space-y-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-7 w-7 shrink-0 text-azure" />
                  <div>
                    <h3 className="font-display text-xl font-bold text-primary">
                      {t(UI_COPY.successTitle)}
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {t(UI_COPY.refCodeLabel)}:{" "}
                      <span className="font-semibold text-foreground">
                        {receipt.referenceCode}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="rounded-xl border border-border bg-surface-subtle p-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {lang === "kk"
                      ? receipt.psychologist.region_name_kk
                      : receipt.psychologist.region_name_ru}
                  </p>
                  <p className="mt-1 font-display text-lg font-bold text-primary">
                    {receipt.psychologist.psychologist_name}
                  </p>
                  <p className="text-sm text-foreground/80">
                    {lang === "kk"
                      ? receipt.psychologist.department_kk
                      : receipt.psychologist.department_ru}
                  </p>
                  <p className="mt-2 text-sm font-medium text-primary">
                    WhatsApp: {receipt.psychologist.phone_display}
                  </p>
                </div>

                <p className="text-sm leading-relaxed text-muted-foreground">
                  {t(UI_COPY.whatsappAutoOpenedNote)}
                </p>

                <div className="flex flex-col gap-3 sm:flex-row">
                  <Button
                    asChild
                    size="lg"
                    className="flex-1 bg-gold text-gold-foreground hover:bg-gold/90"
                  >
                    <a href={receipt.whatsappUrl} target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="h-4 w-4" />
                      {t(UI_COPY.openWhatsappBtn)}
                    </a>
                  </Button>

                  <Button asChild size="lg" variant="outline">
                    <a href={receipt.telUrl}>
                      <Phone className="h-4 w-4" />
                      {t(UI_COPY.callPsychologistBtn)}
                    </a>
                  </Button>
                </div>

                <Button type="button" variant="ghost" onClick={resetForm} className="px-0">
                  {t(UI_COPY.sendAnotherBtn)}
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                <div className="space-y-2">
                  <Label htmlFor="region-select">{t(UI_COPY.regionLabel)} *</Label>
                  <Select value={regionCode} onValueChange={setRegionCode}>
                    <SelectTrigger id="region-select" className="w-full">
                      <SelectValue placeholder={t(UI_COPY.regionPlaceholder)} />
                    </SelectTrigger>
                    <SelectContent>
                      {psychologists.map((item) => (
                        <SelectItem key={item.region_code} value={item.region_code}>
                          {lang === "kk" ? item.region_name_kk : item.region_name_ru}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="topic-select">{t(UI_COPY.topicLabel)}</Label>
                  <Select value={topic} onValueChange={setTopic}>
                    <SelectTrigger id="topic-select" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {APPLICATION_TOPICS.map((item) => (
                        <SelectItem key={item.id} value={item.id}>
                          {item[lang]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-2.5">
                  <Checkbox
                    id="anonymous-toggle"
                    checked={isAnonymous}
                    onCheckedChange={(checked) => setIsAnonymous(checked === true)}
                  />
                  <Label htmlFor="anonymous-toggle" className="cursor-pointer font-normal">
                    {t(UI_COPY.anonymousLabel)}
                  </Label>
                </div>

                {!isAnonymous ? (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="applicant-name">{t(UI_COPY.nameLabel)}</Label>
                      <Input
                        id="applicant-name"
                        value={applicantName}
                        onChange={(e) => setApplicantName(e.target.value)}
                        placeholder={t(UI_COPY.namePlaceholder)}
                        maxLength={120}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact-info">{t(UI_COPY.contactLabel)}</Label>
                      <Input
                        id="contact-info"
                        value={contactInfo}
                        onChange={(e) => setContactInfo(e.target.value)}
                        placeholder={t(UI_COPY.contactPlaceholder)}
                        maxLength={160}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="contact-info-anon">{t(UI_COPY.contactLabel)}</Label>
                    <Input
                      id="contact-info-anon"
                      value={contactInfo}
                      onChange={(e) => setContactInfo(e.target.value)}
                      placeholder={t(UI_COPY.contactPlaceholder)}
                      maxLength={160}
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="message-input">{t(UI_COPY.messageLabel)} *</Label>
                  <Textarea
                    id="message-input"
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder={t(UI_COPY.messagePlaceholder)}
                    maxLength={2000}
                  />
                </div>

                {fieldError ? (
                  <p role="alert" className="text-sm font-medium text-destructive">
                    {fieldError}
                  </p>
                ) : null}

                <Button
                  type="submit"
                  size="lg"
                  disabled={isSubmitting}
                  className="h-auto min-h-11 w-full whitespace-normal bg-primary py-2.5 text-center text-primary-foreground hover:bg-navy-mid"
                >
                  {isSubmitting ? t(UI_COPY.submittingBtn) : t(UI_COPY.submitBtn)}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
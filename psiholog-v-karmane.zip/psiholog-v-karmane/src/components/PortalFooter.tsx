import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { UI_COPY, useLanguage } from "@/lib/i18n";

export function PortalFooter() {
  const { t } = useLanguage();

  return (
    <footer className="bg-navy-deep text-hero-foreground">
      <div className="gold-rule h-1 w-full" />
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-12 md:items-start">
          <div className="md:col-span-7">
            <div className="flex items-center gap-3.5">
              <img
                src={emblemUrl}
                alt={t(UI_COPY.ministry)}
                className="h-14 w-14 shrink-0 object-contain"
              />
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-gold">
                  {t(UI_COPY.ministry)}
                </p>
                <p className="font-display text-xl font-bold text-hero-foreground">
                  {t(UI_COPY.portalName)}
                </p>
              </div>
            </div>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-hero-foreground/80">
              {t(UI_COPY.footerMission)}
            </p>
            <p className="mt-3 text-sm font-semibold text-gold">{t(UI_COPY.footerTagline)}</p>
          </div>

          <div className="md:col-span-5 md:border-l md:border-hero-foreground/15 md:pl-8">
            <p className="text-xs font-semibold uppercase tracking-wider text-gold">
              {t(UI_COPY.footerInitiatorLabel)}
            </p>
            <p className="mt-2 font-display text-base font-bold text-hero-foreground">
              Сеитова Анаргуль Сапаргалиевна
            </p>
            <p className="mt-1 text-sm leading-relaxed text-hero-foreground/75">
              {t(UI_COPY.footerInitiatorRole)}
            </p>
          </div>
        </div>

        <div className="mt-10 border-t border-hero-foreground/15 pt-6 text-xs text-hero-foreground/65">
          © 2026 «Психолог в кармане» — «Қалтадағы психолог» · {t(UI_COPY.ministry)}
        </div>
      </div>
    </footer>
  );
}
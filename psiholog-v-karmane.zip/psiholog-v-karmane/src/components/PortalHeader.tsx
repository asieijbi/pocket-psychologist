import { Link } from "@tanstack/react-router";
import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { UI_COPY, useLanguage } from "@/lib/i18n";
import { Button } from "@/components/ui/button";

export function PortalHeader() {
  const { lang, setLang, t } = useLanguage();

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-card/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-3 group">
          <img
            src={emblemUrl}
            alt={t(UI_COPY.ministry)}
            className="h-11 w-11 shrink-0 object-contain drop-shadow-sm transition-transform group-hover:scale-105 sm:h-12 sm:w-12"
          />
          <div className="min-w-0">
            <p className="truncate text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              {t(UI_COPY.departmentShort)}
            </p>
            <p className="truncate font-display text-base font-bold text-primary sm:text-lg">
              {t(UI_COPY.portalName)}
            </p>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-foreground/80 lg:flex">
          <a href="/#library" className="transition-colors hover:text-primary">
            {t(UI_COPY.navLibrary)}
          </a>
          <a href="/#navigator" className="transition-colors hover:text-primary">
            {t(UI_COPY.navNavigator)}
          </a>
          <a href="/#videos" className="transition-colors hover:text-primary">
            {t(UI_COPY.navVideos)}
          </a>
          <a href="/#apply" className="transition-colors hover:text-primary">
            {t(UI_COPY.navApply)}
          </a>
        </nav>

        <div className="flex shrink-0 items-center gap-2 sm:gap-3">
          <div
            role="group"
            aria-label="Выбор языка / Тілді таңдау"
            className="inline-flex items-center rounded-lg border border-border bg-surface-subtle p-0.5"
          >
            <button
              type="button"
              onClick={() => setLang("ru")}
              aria-pressed={lang === "ru"}
              className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                lang === "ru"
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              РУС
            </button>
            <button
              type="button"
              onClick={() => setLang("kk")}
              aria-pressed={lang === "kk"}
              className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                lang === "kk"
                  ? "bg-primary text-primary-foreground shadow-xs"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              ҚАЗ
            </button>
          </div>

          <Button
            asChild
            size="sm"
            className="hidden bg-gold text-gold-foreground hover:bg-gold/90 sm:inline-flex"
          >
            <a href="/#apply">{t(UI_COPY.navApply)}</a>
          </Button>
        </div>
      </div>
    </header>
  );
}
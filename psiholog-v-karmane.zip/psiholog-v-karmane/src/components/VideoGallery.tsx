import { useState } from "react";
import { Play } from "lucide-react";
import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { FEATURED_VIDEOS, type FeaturedVideo } from "@/data/portal-content";
import { UI_COPY, useLanguage } from "@/lib/i18n";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export function VideoGallery() {
  const { t } = useLanguage();
  const [activeVideo, setActiveVideo] = useState<FeaturedVideo | null>(null);

  return (
    <section id="videos" className="bg-background py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
            {t(UI_COPY.videosTitle)}
          </h2>
          <p className="mt-3 text-base text-muted-foreground">{t(UI_COPY.videosSubtitle)}</p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {FEATURED_VIDEOS.map((video, idx) => (
            <button
              key={video.id}
              type="button"
              onClick={() => setActiveVideo(video)}
              className={`group relative overflow-hidden rounded-xl border border-border bg-navy-deep text-left shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${
                idx === FEATURED_VIDEOS.length - 1 ? "md:col-span-2 md:mx-auto md:w-full md:max-w-2xl" : ""
              }`}
            >
              <div className="relative aspect-16/9 w-full overflow-hidden">
                <img
                  src={video.coverImage}
                  alt={t(video.title)}
                  className="h-full w-full object-cover object-left transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="cover-panel-gradient absolute inset-0" />
                <div className="gold-rule absolute inset-x-0 bottom-0 h-1" />

                <div className="absolute inset-0 flex flex-col justify-between p-4 sm:p-6">
                  <div className="flex items-center justify-end gap-2">
                    <div className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-navy-deep/80 px-3 py-1 backdrop-blur-xs">
                      <img src={emblemUrl} alt="" className="h-5 w-5 object-contain" />
                      <span className="text-[11px] font-semibold tracking-wide text-hero-foreground">
                        {t(UI_COPY.portalName)}
                      </span>
                    </div>
                  </div>

                  <div className="ml-auto flex w-[60%] flex-col items-start sm:w-[55%]">
                    <span className="text-xs font-semibold uppercase tracking-wider text-gold">
                      {t(video.category)}
                    </span>
                    <h3 className="mt-1.5 font-display text-lg font-bold leading-snug text-hero-foreground sm:text-xl">
                      {t(video.title)}
                    </h3>
                    <div className="gold-rule my-2.5 h-0.5 w-24" />
                    <p className="line-clamp-2 text-xs text-hero-foreground/80 sm:text-sm">
                      {t(video.subtitle)}
                    </p>

                    <span className="mt-3.5 inline-flex items-center gap-2 rounded-lg bg-gold px-3.5 py-1.5 text-xs font-semibold text-gold-foreground shadow-sm transition-transform group-hover:translate-x-0.5">
                      <Play className="h-3.5 w-3.5 fill-current" />
                      {t(UI_COPY.watchVideo)}
                    </span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <Dialog open={activeVideo !== null} onOpenChange={(open) => !open && setActiveVideo(null)}>
        <DialogContent className="max-w-3xl overflow-hidden p-0">
          {activeVideo ? (
            <>
              <div className="aspect-video w-full bg-navy-deep">
                <iframe
                  src={`https://www.youtube.com/embed/${activeVideo.youtubeId}?autoplay=1&rel=0`}
                  title={t(activeVideo.title)}
                  className="h-full w-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <DialogHeader className="px-6 py-4">
                <DialogTitle className="text-lg font-bold text-primary">
                  {t(activeVideo.title)}
                </DialogTitle>
                <DialogDescription>{t(activeVideo.subtitle)}</DialogDescription>
              </DialogHeader>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </section>
  );
}
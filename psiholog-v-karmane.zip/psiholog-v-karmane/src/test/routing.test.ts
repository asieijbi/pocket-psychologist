import { describe, expect, it } from "vitest";
import {
  applicationSchema,
  buildWhatsAppHandoffUrl,
  findPsychologistByRegion,
  type RegionalPsychologist,
} from "@/lib/routing";

const SAMPLE_PSYCHOLOGISTS: RegionalPsychologist[] = [
  {
    id: "1",
    region_code: "akmola",
    region_name_ru: "Акмолинская область",
    region_name_kk: "Ақмола облысы",
    psychologist_name: "Сеитова Анаргуль Сапаргалиевна",
    rank_ru: "Старший инспектор-психолог ГРЛС, подполковник полиции",
    rank_kk: "ЖҚЖТ аға инспектор-психологы, полиция подполковнигі",
    department_ru: "УССО Акмолинской области ККОД МВД РК",
    department_kk: "ҚР ІІМ КҚБК Ақмола облысының МКҚБ",
    whatsapp_number: "77779565512",
    phone_display: "+7 (777) 956-55-12",
    is_demo: false,
    sort_order: 1,
  },
  {
    id: "2",
    region_code: "almaty_city",
    region_name_ru: "г. Алматы",
    region_name_kk: "Алматы қ.",
    psychologist_name: "Касымова Динара Ерлановна",
    rank_ru: "Старший инспектор-психолог, майор полиции",
    rank_kk: "Аға инспектор-психолог, полиция майоры",
    department_ru: "ДП г. Алматы МВД РК",
    department_kk: "ҚР ІІМ Алматы қ. ПД",
    whatsapp_number: "77001030003",
    phone_display: "+7 (700) 103-00-03",
    is_demo: true,
    sort_order: 3,
  },
];

describe("Regional psychologist routing and application validation", () => {
  it("routes selected region to that region's assigned psychologist", () => {
    const akmola = findPsychologistByRegion(SAMPLE_PSYCHOLOGISTS, "akmola");
    expect(akmola?.psychologist_name).toBe("Сеитова Анаргуль Сапаргалиевна");

    const almaty = findPsychologistByRegion(SAMPLE_PSYCHOLOGISTS, "almaty_city");
    expect(almaty?.psychologist_name).toBe("Касымова Динара Ерлановна");

    const unknown = findPsychologistByRegion(SAMPLE_PSYCHOLOGISTS, "unknown_region");
    expect(unknown).toBeUndefined();
  });

  it("rejects empty region or too-short messages", () => {
    const missingRegion = applicationSchema.safeParse({
      regionCode: "",
      topic: "stress",
      message: "Мне нужна поддержка психолога после смены",
      isAnonymous: true,
      language: "ru",
    });
    expect(missingRegion.success).toBe(false);

    const shortMessage = applicationSchema.safeParse({
      regionCode: "akmola",
      topic: "stress",
      message: "123",
      isAnonymous: true,
      language: "ru",
    });
    expect(shortMessage.success).toBe(false);
  });

  it("builds a properly encoded WhatsApp handoff URL in Russian and Kazakh", () => {
    const psychologist = SAMPLE_PSYCHOLOGISTS[0];
    expect(psychologist).toBeDefined();
    if (!psychologist) return;

    const ruUrl = buildWhatsAppHandoffUrl({
      psychologist,
      referenceCode: "PK-2026-4821",
      topicLabel: "Стресс и напряжение на службе",
      message: "Нужна консультация после ночной смены",
      isAnonymous: true,
      contactInfo: "+7 701 555 44 33",
      language: "ru",
    });
    expect(ruUrl.startsWith("https://wa.me/77779565512?text=")).toBe(true);
    expect(decodeURIComponent(ruUrl)).toContain("Сеитова Анаргуль Сапаргалиевна");
    expect(decodeURIComponent(ruUrl)).toContain("Акмолинская область");
    expect(decodeURIComponent(ruUrl)).toContain("PK-2026-4821");
    expect(decodeURIComponent(ruUrl)).toContain("+7 701 555 44 33");

    const kkUrl = buildWhatsAppHandoffUrl({
      psychologist,
      referenceCode: "PK-2026-4822",
      topicLabel: "Қызметтегі күйзеліс пен ширығу",
      message: "Кезекшіліктен кейін кеңес қажет",
      isAnonymous: true,
      language: "kk",
    });
    expect(decodeURIComponent(kkUrl)).toContain("Ақмола облысы");
    expect(decodeURIComponent(kkUrl)).toContain("Анонимді");
  });
});
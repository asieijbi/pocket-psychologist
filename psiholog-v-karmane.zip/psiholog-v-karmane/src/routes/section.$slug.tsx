import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle2, MessageCircle } from "lucide-react";
import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { LIBRARY_SECTIONS } from "@/data/portal-content";
import { UI_COPY, useLanguage } from "@/lib/i18n";
import { PortalHeader } from "@/components/PortalHeader";
import { PortalFooter } from "@/components/PortalFooter";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/section/$slug")({
  loader: ({ params }) => {
    const section = LIBRARY_SECTIONS.find((s) => s.slug === params.slug);
    if (!section) {
      throw notFound();
    }
    return section;
  },
  head: ({ loaderData }) => {
    const title = loaderData
      ? `${loaderData.title.ru} | Психолог в кармане — МВД РК`
      : "Психологическая библиотека — МВД РК";
    const description = loaderData
      ? loaderData.shortDesc.ru
      : "Материалы психологической поддержки сотрудников органов внутренних дел РК.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: SectionDetailPage,
});

function SectionDetailPage() {
  const section = Route.useLoaderData();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <PortalHeader />

      <main>
        <section className="relative isolate overflow-hidden bg-navy-deep">
          <img
            src={section.coverImage}
            alt={t(section.title)}
            className="absolute inset-0 -z-20 h-full w-full object-cover object-top"
          />
          <div className="hero-scrim absolute inset-0 -z-10" />

          <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 sm:py-16">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-sm font-medium text-gold transition-colors hover:text-hero-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              {t(UI_COPY.backHome)}
            </Link>

            <div className="mt-6 flex items-center gap-3">
              <img src={emblemUrl} alt="" className="h-11 w-11 object-contain" />
              <p className="text-xs font-semibold uppercase tracking-wider text-gold">
                {t(UI_COPY.libraryTitle)}
              </p>
            </div>

            <h1 className="mt-4 font-display text-3xl font-extrabold leading-tight text-hero-foreground sm:text-5xl">
              {t(section.title)}
            </h1>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-hero-foreground/85 sm:text-lg">
              {t(section.shortDesc)}
            </p>
          </div>
          <div className="gold-rule h-1 w-full" />
        </section>

        <article className="mx-auto max-w-4xl space-y-10 px-4 py-12 sm:px-6 sm:py-16">
          <blockquote className="rounded-xl border-l-4 border-gold bg-surface-subtle p-6 font-display text-lg font-semibold leading-relaxed text-primary">
            «{t(section.quote)}»
          </blockquote>

          <p className="text-base leading-relaxed text-foreground/90">{t(section.intro)}</p>

          <div>
            <h2 className="font-display text-2xl font-bold text-primary">
              {t(UI_COPY.sectionRecommendations)}
            </h2>
            <ul className="mt-5 space-y-3.5">
              {section.recommendations.map((rec, index) => (
                <li
                  key={index}
                  className="flex items-start gap-3 rounded-xl border border-border bg-card p-4"
                >
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-azure" />
                  <span className="text-sm leading-relaxed text-foreground/90 sm:text-base">
                    {t(rec)}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-xl border border-gold/50 bg-gold-soft/50 p-6">
            <p className="text-xs font-bold uppercase tracking-wider text-primary">
              {t(UI_COPY.sectionRemember)}
            </p>
            <p className="mt-2 text-base font-medium leading-relaxed text-foreground">
              {t(section.remember)}
            </p>
          </div>

          {section.youtubeIds.length > 0 ? (
            <div>
              <h2 className="font-display text-2xl font-bold text-primary">
                {t(UI_COPY.sectionVideos)}
              </h2>
              <div className="mt-5 grid gap-6 sm:grid-cols-2">
                {section.youtubeIds.map((vid) => (
                  <div
                    key={vid.id}
                    className="overflow-hidden rounded-xl border border-border bg-card shadow-xs"
                  >
                    <div className="aspect-video w-full bg-navy-deep">
                      <iframe
                        src={`https://www.youtube.com/embed/${vid.id}?rel=0`}
                        title={t(vid.title)}
                        className="h-full w-full border-0"
                        loading="lazy"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                    <p className="p-3.5 text-sm font-medium text-primary">{t(vid.title)}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-navy-deep p-6 text-hero-foreground sm:p-8">
            <div>
              <p className="font-display text-xl font-bold">{t(UI_COPY.applyTitle)}</p>
              <p className="mt-1 text-sm text-hero-foreground/80">
                {t(UI_COPY.confidentialNote)}
              </p>
            </div>
            <Button
              asChild
              size="lg"
              className="bg-gold font-semibold text-gold-foreground hover:bg-gold/90"
            >
              <a href="/#apply">
                <MessageCircle className="h-4 w-4" />
                {t(UI_COPY.heroCtaApply)}
              </a>
            </Button>
          </div>
        </article>
      </main>

      <PortalFooter />
    </div>
  );
}
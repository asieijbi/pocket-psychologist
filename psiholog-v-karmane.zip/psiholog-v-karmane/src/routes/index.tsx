import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import emblemUrl from "@/assets/mvd-rk-emblem.png";
import { LIBRARY_SECTIONS, PORTAL_IMAGES, YOUNG_OFFICER_FAQ } from "@/data/portal-content";
import { UI_COPY, useLanguage } from "@/lib/i18n";
import { listRegionalPsychologists } from "@/lib/psychologists.functions";
import { PortalHeader } from "@/components/PortalHeader";
import { VideoGallery } from "@/components/VideoGallery";
import { ApplicationSection } from "@/components/ApplicationSection";
import { PortalFooter } from "@/components/PortalFooter";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const psychologistsQueryOptions = queryOptions({
  queryKey: ["regional-psychologists"],
  queryFn: () => listRegionalPsychologists(),
  staleTime: 5 * 60 * 1000,
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Психолог в кармане | Қалтадағы психолог — МВД РК" },
      {
        name: "description",
        content:
          "Информационно-психологический портал МВД РК: библиотека, навигатор молодого сотрудника, видеоматериалы и обращение к психологу вашей области.",
      },
      { property: "og:title", content: "Психолог в кармане | Қалтадағы психолог — МВД РК" },
      {
        property: "og:description",
        content:
          "Психологическая поддержка сотрудников полиции Казахстана на русском и казахском языках с распределением заявок по областям.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(psychologistsQueryOptions),
  component: HomePage,
});

function HomePage() {
  const { t } = useLanguage();
  const { data: psychologists } = useSuspenseQuery(psychologistsQueryOptions);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <PortalHeader />

      <main>
        <section className="relative isolate overflow-hidden bg-navy-deep">
          <img
            src={PORTAL_IMAGES.heroOfficers}
            alt={t(UI_COPY.portalName)}
            className="absolute inset-0 -z-20 h-full w-full object-cover object-top sm:object-center"
          />
          <div className="hero-scrim absolute inset-0 -z-10" />

          <div className="mx-auto flex min-h-[540px] max-w-6xl flex-col justify-center px-4 py-16 sm:min-h-[600px] sm:px-6 sm:py-24">
            <div className="max-w-2xl">
              <div className="flex items-center gap-3">
                <img
                  src={emblemUrl}
                  alt={t(UI_COPY.ministry)}
                  className="h-14 w-14 shrink-0 object-contain drop-shadow-md sm:h-16 sm:w-16"
                />
                <p className="hero-text-shadow text-xs font-semibold uppercase tracking-[0.14em] text-gold sm:text-sm">
                  {t(UI_COPY.heroEyebrow)}
                </p>
              </div>

              <h1 className="hero-text-shadow mt-5 font-display text-5xl font-bold leading-[1.08] tracking-tight text-hero-foreground sm:text-6xl lg:text-7xl">
                {t(UI_COPY.heroTitle)}
              </h1>

              <p className="hero-text-shadow mt-5 max-w-xl text-base leading-relaxed text-hero-foreground/95 sm:text-lg">
                {t(UI_COPY.heroSubtitle)}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3.5">
                <Button
                  asChild
                  size="lg"
                  className="bg-gold px-6 font-semibold text-gold-foreground hover:bg-gold/90"
                >
                  <a href="#apply">{t(UI_COPY.heroCtaApply)}</a>
                </Button>

                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="border-hero-foreground/35 bg-navy-deep/45 text-hero-foreground backdrop-blur-xs hover:bg-navy-deep/75 hover:text-hero-foreground"
                >
                  <a href="#library">{t(UI_COPY.heroCtaLibrary)}</a>
                </Button>
              </div>
            </div>
          </div>
          <div className="gold-rule h-1 w-full" />
        </section>

        <section id="library" className="bg-background py-16 sm:py-20">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="max-w-2xl">
              <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                {t(UI_COPY.libraryTitle)}
              </h2>
              <p className="mt-3 text-base text-muted-foreground">{t(UI_COPY.librarySubtitle)}</p>
            </div>

            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {LIBRARY_SECTIONS.map((section, idx) => (
                <Link
                  key={section.slug}
                  to="/section/$slug"
                  params={{ slug: section.slug }}
                  className={`group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-xs transition-all hover:-translate-y-0.5 hover:border-gold/70 hover:shadow-md ${
                    idx === 0 ? "sm:col-span-2 lg:col-span-2" : ""
                  }`}
                >
                  <div
                    className={`relative w-full overflow-hidden bg-navy-deep ${
                      idx === 0 ? "aspect-16/9 sm:aspect-21/9" : "aspect-16/10"
                    }`}
                  >
                    <img
                      src={section.coverImage}
                      alt={t(section.title)}
                      className="h-full w-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="cover-panel-gradient absolute inset-0" />
                    <div className="gold-rule absolute inset-x-0 bottom-0 h-0.5" />

                    <div className="absolute inset-0 flex flex-col justify-between p-4 sm:p-5">
                      <div className="flex justify-end">
                        <img
                          src={emblemUrl}
                          alt=""
                          className="h-8 w-8 object-contain drop-shadow-sm"
                        />
                      </div>

                      <div className="ml-auto w-[68%] sm:w-[64%]">
                        <h3 className="break-words font-display text-base font-bold leading-snug text-hero-foreground sm:text-lg">
                          {t(section.title)}
                        </h3>
                        <div className="gold-rule mt-2 h-0.5 w-16" />
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-1 flex-col justify-between p-5">
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {t(section.shortDesc)}
                    </p>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary group-hover:text-azure">
                      {t(UI_COPY.readSection)}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section id="navigator" className="border-y border-border bg-surface-subtle py-16 sm:py-20">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="grid gap-10 lg:grid-cols-12 lg:items-center">
              <div className="lg:col-span-5">
                <div className="relative overflow-hidden rounded-2xl border border-border bg-navy-deep shadow-md">
                  <img
                    src={PORTAL_IMAGES.navigatorYoung}
                    alt={t(UI_COPY.navigatorTitle)}
                    className="aspect-4/3 w-full object-cover object-top"
                    loading="lazy"
                  />
                  <div className="gold-rule h-1 w-full" />
                  <div className="flex items-center gap-3 p-4">
                    <img
                      src={emblemUrl}
                      alt=""
                      className="h-10 w-10 shrink-0 object-contain"
                    />
                    <p className="text-sm font-semibold text-hero-foreground">
                      {t(UI_COPY.navigatorTitle)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7">
                <h2 className="text-3xl font-bold tracking-tight text-primary sm:text-4xl">
                  {t(UI_COPY.navigatorTitle)}
                </h2>
                <p className="mt-3 text-base text-muted-foreground">
                  {t(UI_COPY.navigatorSubtitle)}
                </p>

                <Accordion
                  type="single"
                  collapsible
                  defaultValue="fear-mistakes"
                  className="mt-6 space-y-3"
                >
                  {YOUNG_OFFICER_FAQ.map((item) => (
                    <AccordionItem
                      key={item.id}
                      value={item.id}
                      className="rounded-xl border border-border bg-card px-5 shadow-2xs"
                    >
                      <AccordionTrigger className="py-4 text-left font-display text-base font-bold text-primary hover:no-underline">
                        {t(item.question)}
                      </AccordionTrigger>
                      <AccordionContent className="pb-5">
                        <p className="text-xs font-semibold uppercase tracking-wider text-azure">
                          {t(UI_COPY.psychologistAdviceLabel)}
                        </p>
                        <p className="mt-2 text-sm leading-relaxed text-foreground/85">
                          {t(item.answer)}
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </div>
          </div>
        </section>

        <VideoGallery />

        <ApplicationSection psychologists={psychologists} />
      </main>

      <PortalFooter />
    </div>
  );
}

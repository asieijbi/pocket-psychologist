import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import {
  APPLICATION_TOPICS,
  applicationSchema,
  buildWhatsAppHandoffUrl,
  type RegionalPsychologist,
} from "./routing";

export const listRegionalPsychologists = createServerFn({ method: "GET" }).handler(
  async (): Promise<RegionalPsychologist[]> => {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) {
      throw new Error("Backend environment variables are not configured");
    }

    const supabasePublic = createClient<Database>(url, key, {
      auth: { persistSession: false },
      global: {
        fetch: (input, init) => {
          const headers = new Headers(init?.headers);
          if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
            headers.delete("Authorization");
          }
          headers.set("apikey", key);
          return fetch(input, { ...init, headers });
        },
      },
    });

    const { data, error } = await supabasePublic
      .from("regional_psychologists")
      .select(
        "id, region_code, region_name_ru, region_name_kk, psychologist_name, rank_ru, rank_kk, department_ru, department_kk, whatsapp_number, phone_display, is_demo, sort_order",
      )
      .order("sort_order", { ascending: true })
      .limit(50);

    if (error) {
      console.error("Failed to fetch regional psychologists:", error);
      throw new Error("Не удалось загрузить список психологов по областям");
    }

    return data ?? [];
  },
);

export interface ApplicationReceipt {
  id: string;
  referenceCode: string;
  psychologist: RegionalPsychologist;
  whatsappUrl: string;
  telUrl: string;
}

export const submitPsychologistApplication = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => applicationSchema.parse(data))
  .handler(async ({ data }): Promise<ApplicationReceipt> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: psychologist, error: lookupError } = await supabaseAdmin
      .from("regional_psychologists")
      .select(
        "id, region_code, region_name_ru, region_name_kk, psychologist_name, rank_ru, rank_kk, department_ru, department_kk, whatsapp_number, phone_display, is_demo, sort_order",
      )
      .eq("region_code", data.regionCode)
      .maybeSingle();

    if (lookupError || !psychologist) {
      throw new Error("Выбранная область не найдена в справочнике психологов");
    }

    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const referenceCode = `PK-${new Date().getFullYear()}-${randomDigits}`;
    const topicEntry = APPLICATION_TOPICS.find((item) => item.id === data.topic);
    const topicLabel = topicEntry ? topicEntry[data.language] : data.topic;
    const regionName =
      data.language === "kk" ? psychologist.region_name_kk : psychologist.region_name_ru;

    const { data: inserted, error: insertError } = await supabaseAdmin
      .from("psychologist_applications")
      .insert({
        reference_code: referenceCode,
        psychologist_id: psychologist.id,
        region_code: psychologist.region_code,
        region_name: regionName,
        assigned_psychologist_name: psychologist.psychologist_name,
        applicant_name: data.isAnonymous ? null : data.applicantName || null,
        contact_info: data.contactInfo || null,
        topic: topicLabel,
        message: data.message,
        is_anonymous: data.isAnonymous,
        language: data.language,
        status: "routed",
      })
      .select("id")
      .single();

    if (insertError || !inserted) {
      console.error("Failed to insert psychologist application:", insertError);
      throw new Error("Не удалось сохранить обращение. Попробуйте ещё раз.");
    }

    const whatsappUrl = buildWhatsAppHandoffUrl({
      psychologist,
      referenceCode,
      topicLabel,
      message: data.message,
      isAnonymous: data.isAnonymous,
      applicantName: data.isAnonymous ? undefined : data.applicantName,
      contactInfo: data.contactInfo,
      language: data.language,
    });

    const cleanPhone = psychologist.whatsapp_number.replace(/\D/g, "");

    return {
      id: inserted.id,
      referenceCode,
      psychologist,
      whatsappUrl,
      telUrl: `tel:+${cleanPhone}`,
    };
  });
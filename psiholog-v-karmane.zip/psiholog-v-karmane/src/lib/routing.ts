import { z } from "zod";
import type { Language } from "./i18n";

export interface RegionalPsychologist {
  id: string;
  region_code: string;
  region_name_ru: string;
  region_name_kk: string;
  psychologist_name: string;
  rank_ru: string;
  rank_kk: string;
  department_ru: string;
  department_kk: string;
  whatsapp_number: string;
  phone_display: string;
  is_demo: boolean;
  sort_order: number;
}

export const APPLICATION_TOPICS = [
  { id: "stress", ru: "Стресс и напряжение на службе", kk: "Қызметтегі күйзеліс пен ширығу" },
  { id: "burnout", ru: "Эмоциональное выгорание и усталость", kk: "Эмоциялық қажу және шаршау" },
  { id: "conflicts", ru: "Конфликтная ситуация или провокация", kk: "Жанжал немесе арандатушылық жағдай" },
  { id: "family", ru: "Семья и личные отношения", kk: "Отбасы және жеке қарым-қатынас" },
  { id: "sleep", ru: "Сон и восстановление после смен", kk: "Ұйқы және ауысымнан кейін қалпына келу" },
  { id: "adaptation", ru: "Адаптация молодого сотрудника", kk: "Жас қызметкердің бейімделуі" },
  { id: "other", ru: "Другой вопрос — мне нужно поговорить", kk: "Басқа сұрақ — маған сөйлесу керек" },
] as const;

export const applicationSchema = z.object({
  regionCode: z.string().trim().min(2, "Выберите область Казахстана").max(40),
  topic: z.string().trim().min(2, "Выберите тему обращения").max(120),
  message: z
    .string()
    .trim()
    .min(5, "Опишите ваш вопрос (минимум 5 символов)")
    .max(2000, "Сообщение не должно превышать 2000 символов"),
  isAnonymous: z.boolean(),
  applicantName: z.string().trim().max(120).optional(),
  contactInfo: z.string().trim().max(160).optional(),
  language: z.enum(["ru", "kk"]),
});

export type ApplicationInput = z.infer<typeof applicationSchema>;

export function findPsychologistByRegion(
  psychologists: readonly RegionalPsychologist[],
  regionCode: string,
): RegionalPsychologist | undefined {
  const normalized = regionCode.trim().toLowerCase();
  return psychologists.find((p) => p.region_code.toLowerCase() === normalized);
}

export function buildWhatsAppHandoffUrl(params: {
  psychologist: RegionalPsychologist;
  referenceCode: string;
  topicLabel: string;
  message: string;
  isAnonymous: boolean;
  applicantName?: string | undefined;
  contactInfo?: string | undefined;
  language: Language;
}): string {
  const cleanPhone = params.psychologist.whatsapp_number.replace(/\D/g, "");
  const regionName =
    params.language === "kk"
      ? params.psychologist.region_name_kk
      : params.psychologist.region_name_ru;

  const greeting =
    params.language === "kk"
      ? `Сәлеметсіз бе, ${params.psychologist.psychologist_name}! «Қалтадағы психолог» порталы арқылы өтініш (${params.referenceCode}).`
      : `Здравствуйте, ${params.psychologist.psychologist_name}! Обращение с портала «Психолог в кармане» (${params.referenceCode}).`;

  const regionLine =
    params.language === "kk" ? `Өңір: ${regionName}` : `Регион: ${regionName}`;
  const topicLine =
    params.language === "kk" ? `Тақырып: ${params.topicLabel}` : `Тема: ${params.topicLabel}`;
  const senderLine = params.isAnonymous
    ? params.language === "kk"
      ? "Өтініш форматы: Анонимді"
      : "Формат: Анонимно"
    : params.applicantName
      ? params.language === "kk"
        ? `Аты-жөні: ${params.applicantName}`
        : `Имя: ${params.applicantName}`
      : "";

  const contactLine = params.contactInfo
    ? params.language === "kk"
      ? `Байланыс: ${params.contactInfo}`
      : `Контакт: ${params.contactInfo}`
    : "";

  const shortMessage =
    params.message.length > 500 ? `${params.message.slice(0, 497)}...` : params.message;
  const msgLine =
    params.language === "kk" ? `Хабарлама: ${shortMessage}` : `Сообщение: ${shortMessage}`;

  const lines = [greeting, regionLine, topicLine, senderLine, contactLine, msgLine].filter(Boolean);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(lines.join("\n"))}`;
}
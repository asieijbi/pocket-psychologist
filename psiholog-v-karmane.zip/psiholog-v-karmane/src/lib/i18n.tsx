import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Language = "ru" | "kk";

export interface BilingualText {
  ru: string;
  kk: string;
}

interface LanguageContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (text: BilingualText) => string;
}

const STORAGE_KEY = "psiholog-v-karmane-lang";

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>("ru");

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      if (saved === "ru" || saved === "kk") {
        setLangState(saved);
        document.documentElement.lang = saved;
      }
    } catch {
      // Ignore storage access errors
    }
  }, []);

  const setLang = (next: Language) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
      document.documentElement.lang = next;
    } catch {
      // Ignore storage access errors
    }
  };

  const t = (text: BilingualText) => text[lang];

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return ctx;
}

export const UI_COPY = {
  ministry: {
    ru: "Министерство внутренних дел Республики Казахстан",
    kk: "Қазақстан Республикасы Ішкі істер министрлігі",
  },
  departmentShort: {
    ru: "ККОД МВД РК · Психологическая служба",
    kk: "ҚР ІІМ КҚБК · Психологиялық қызмет",
  },
  portalName: {
    ru: "Психолог в кармане",
    kk: "Қалтадағы психолог",
  },
  navLibrary: { ru: "Библиотека", kk: "Кітапхана" },
  navNavigator: { ru: "Навигатор", kk: "Навигатор" },
  navVideos: { ru: "Видео", kk: "Бейнежазбалар" },
  navApply: { ru: "Заявка психологу", kk: "Психологқа өтініш" },
  heroEyebrow: {
    ru: "МВД Республики Казахстан · Психологическая поддержка",
    kk: "ҚР Ішкі істер министрлігі · Психологиялық қолдау",
  },
  heroTitle: {
    ru: "Психолог в кармане",
    kk: "Қалтадағы психолог",
  },
  heroSubtitle: {
    ru: "Практические рекомендации, видеоматериалы и конфиденциальная связь с психологом вашей области — всегда рядом на службе и дома.",
    kk: "Практикалық ұсынымдар, бейнематериалдар және өз облысыңыздың психологымен құпия байланыс — қызметте де, үйде де әрқашан жаныңызда.",
  },
  heroCtaApply: {
    ru: "Обратиться к психологу",
    kk: "Психологқа жүгіну",
  },
  heroCtaLibrary: {
    ru: "Открыть библиотеку",
    kk: "Кітапхананы ашу",
  },
  libraryTitle: {
    ru: "Психологическая библиотека",
    kk: "Психологиялық кітапхана",
  },
  librarySubtitle: {
    ru: "Выберите интересующий раздел — внутри рекомендации психолога, упражнения и обучающие видео.",
    kk: "Қажетті бөлімді таңдаңыз — ішінде психолог кеңестері, жаттығулар және оқыту бейнежазбалары бар.",
  },
  readSection: {
    ru: "Открыть раздел",
    kk: "Бөлімді ашу",
  },
  navigatorTitle: {
    ru: "Навигатор молодого сотрудника",
    kk: "Жас қызметкерге арналған навигатор",
  },
  navigatorSubtitle: {
    ru: "Поддержка, советы и практические рекомендации для уверенной адаптации на службе. Нажмите на вопрос, чтобы открыть совет психолога.",
    kk: "Қызметке сенімді бейімделуге арналған қолдау, кеңестер мен практикалық нұсқаулықтар. Психолог кеңесін оқу үшін сұрақты басыңыз.",
  },
  psychologistAdviceLabel: {
    ru: "Совет психолога",
    kk: "Психолог кеңесі",
  },
  videosTitle: {
    ru: "Видеоматериалы",
    kk: "Бейнежазбалар",
  },
  videosSubtitle: {
    ru: "Короткие практические видео о саморегуляции, стрессоустойчивости и сохранении внутреннего ресурса.",
    kk: "Өзін-өзі реттеу, күйзеліске төзімділік және ішкі ресурсты сақтау туралы қысқа практикалық бейнежазбалар.",
  },
  watchVideo: {
    ru: "Смотреть видео",
    kk: "Бейнені көру",
  },
  applyTitle: {
    ru: "Мне нужно поговорить",
    kk: "Маған сөйлесу керек",
  },
  applySubtitle: {
    ru: "Выберите вашу область Казахстана — заявка сохранится и автоматически перенаправит вас к психологу вашего региона. Можно обратиться анонимно.",
    kk: "Қазақстанның өз облысыңызды таңдаңыз — өтініш сақталып, сізді өңіріңіздің психологына автоматты түрде бағыттайды. Анонимді жүгінуге болады.",
  },
  regionLabel: {
    ru: "Область или город республиканского значения",
    kk: "Облыс немесе республикалық маңызы бар қала",
  },
  regionPlaceholder: {
    ru: "Выберите регион Казахстана...",
    kk: "Қазақстан өңірін таңдаңыз...",
  },
  assignedLabel: {
    ru: "Автоматическое распределение · Психолог региона",
    kk: "Автоматты бөлу · Өңір психологы",
  },
  demoContactNote: {
    ru: "Контактный номер WhatsApp указан для демонстрации — администратор может заменить его на актуальный.",
    kk: "WhatsApp байланыс нөмірі көрсету мақсатында берілген — әкімші оны нақты нөмірге ауыстыра алады.",
  },
  topicLabel: { ru: "Тема обращения", kk: "Өтініш тақырыбы" },
  anonymousLabel: {
    ru: "Отправить анонимно (без указания имени)",
    kk: "Анонимді түрде жіберу (атын көрсетпей)",
  },
  nameLabel: { ru: "Ваше имя (по желанию)", kk: "Аты-жөніңіз (қалауыңызша)" },
  namePlaceholder: { ru: "Например: Ерлан", kk: "Мысалы: Ерлан" },
  contactLabel: {
    ru: "Удобный способ связи (по желанию)",
    kk: "Байланысу тәсілі (қалауыңызша)",
  },
  contactPlaceholder: {
    ru: "Телефон, WhatsApp или Telegram",
    kk: "Телефон, WhatsApp немесе Telegram",
  },
  messageLabel: { ru: "Ваше сообщение психологу", kk: "Психологқа хабарламаңыз" },
  messagePlaceholder: {
    ru: "Поделитесь переживаниями или задайте вопрос психологу...",
    kk: "Уайымдарыңызбен бөлісіңіз немесе психологқа сұрақ қойыңыз...",
  },
  submitBtn: {
    ru: "Отправить заявку в WhatsApp психологу",
    kk: "Өтінішті психологтың WhatsApp-ына жіберу",
  },
  submittingBtn: { ru: "Направляем заявку...", kk: "Өтініш бағытталуда..." },
  successTitle: {
    ru: "Заявка принята и направлена психологу региона",
    kk: "Өтініш қабылданып, өңір психологына бағытталды",
  },
  refCodeLabel: { ru: "Номер обращения", kk: "Өтініш нөмірі" },
  openWhatsappBtn: {
    ru: "Открыть чат WhatsApp с психологом",
    kk: "Психологпен WhatsApp чатын ашу",
  },
  whatsappAutoOpenedNote: {
    ru: "Чат WhatsApp с готовым текстом заявки открывается автоматически. Если окно не открылось, нажмите кнопку ниже.",
    kk: "Өтініш мәтіні дайын WhatsApp чаты автоматты түрде ашылады. Егер терезе ашылмаса, төмендегі батырманы басыңыз.",
  },
  callPsychologistBtn: { ru: "Позвонить", kk: "Қоңырау шалу" },
  sendAnotherBtn: { ru: "Отправить новое обращение", kk: "Жаңа өтініш жіберу" },
  backHome: { ru: "На главную", kk: "Басты бетке" },
  sectionRecommendations: {
    ru: "Рекомендации психолога",
    kk: "Психолог ұсынымдары",
  },
  sectionVideos: {
    ru: "Видео по теме",
    kk: "Тақырып бойынша бейнежазбалар",
  },
  sectionRemember: { ru: "Важно помнить", kk: "Есте сақтаңыз" },
  footerMission: {
    ru: "Проект «Психолог в кармане» создан для укрепления психологической устойчивости, сохранения эмоционального благополучия и профессионального здоровья сотрудников органов внутренних дел.",
    kk: "«Қалтадағы психолог» жобасы ішкі істер органдары қызметкерлерінің психологиялық тұрақтылығын нығайту, эмоциялық әл-ауқатын және кәсіби денсаулығын сақтау мақсатында құрылды.",
  },
  footerInitiatorLabel: {
    ru: "Инициатор и разработчик проекта",
    kk: "Жобаның бастамашысы және әзірлеушісі",
  },
  footerInitiatorRole: {
    ru: "Старший инспектор-психолог ГРЛС УССО Акмолинской области ККОД МВД РК, подполковник полиции",
    kk: "ҚР ІІМ КҚБК Ақмола облысы МКҚБ ЖҚЖТ аға инспектор-психологы, полиция подполковнигі",
  },
  footerTagline: {
    ru: "Психологическая поддержка всегда рядом!",
    kk: "Психологиялық қолдау әрқашан жаныңызда!",
  },
  confidentialNote: {
    ru: "Все обращения строго конфиденциальны",
    kk: "Барлық өтініштер қатаң құпия сақталады",
  },
} as const;